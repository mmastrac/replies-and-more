Replies and More for Google+
============================

This extension uses HTML scraping to add additional functionality to the Google+ interfaces in the Chrome browser. 
It takes advantage of Chrome's excellent HTML5 support to do this efficiently.

[![Build Status](https://travis-ci.org/mmastrac/replies-and-more.svg?branch=master)](https://travis-ci.org/mmastrac/replies-and-more)

